import { Composer as BaseComposer } from 'grammy'
import { Context } from './context'

export class Composer extends BaseComposer<Context> {
  //
}
